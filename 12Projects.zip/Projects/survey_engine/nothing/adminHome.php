<link rel="stylesheet" href="../includes/style.css" type="text/css" media="screen" />
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<?php
		$page_title= 'Administrator Login';
		include('../includes/headerAdmin.html');
		
	?>
    <!-- Start of the page-specific content. -->
		<h1>Admin Control Panel</h1>
      	<p>Welcome, Admin!</p>
        <p>Here is a list of functions you may perform:</p>
        <p>1. Add a question</p>
        <p>3. Change the active Question of the Day/Week</p>
        <p>4. Log out and return to user view</p>
				
	<!-- End of the page-specific content. --></div>
	
<?php
    include('../includes/footer.html');
    ?>
</body>
</html>