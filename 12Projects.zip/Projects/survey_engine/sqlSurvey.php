<?PHP

	//get question number from file
	$num = file_get_contents("nothing/qOfDay.txt");
	$qNum = 'q'.$num;


	//get question from database

	$SQL = "SELECT * FROM sn2395790_entity_tblquestions WHERE sn2395790_entity_tblquestions.QID = '$qNum'";

?>